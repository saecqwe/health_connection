enum ApiCurrentState { initial, loading, loaded, error }
