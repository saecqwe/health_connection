import 'package:flutter/material.dart';
import 'dart:ui' as ui;

Size get get => ui.window.physicalSize / ui.window.devicePixelRatio;

double getHeight = get.height;
double getWidth = get.width;
